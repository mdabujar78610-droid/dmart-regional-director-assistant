"""DMart Part C analytics agent package."""
